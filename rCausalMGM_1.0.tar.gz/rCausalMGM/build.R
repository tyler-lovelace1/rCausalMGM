library(RcppArmadillo)
Rcpp::compileAttributes(".")

