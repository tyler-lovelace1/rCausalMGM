#' A print override function for the graph
#'
#' @param x The graph object
#' @export
print.graph <- function(x) {
    cat("Algorithm: ", x[["algorithm"]], "\n")
    cat("Nodes: ", length(x[["nodes"]]), "\n")
    cat("Edges: ", length(x[["edges"]]), "\n")
    if (x[["type"]] != "undirected") {
        if (x[["type"]] == "partial ancestral graph") {
            cat("  Unoriented: ", length(which(grepl("o-o", x[["edges"]], fixed=TRUE))), "\n")
            cat("  Partially Oriented: ", length(which(grepl("o->", x[["edges"]], fixed=TRUE))), "\n")
        } else {
            cat("  Undirected: ", length(which(grepl("---", x[["edges"]], fixed=TRUE))), "\n")
        }
        cat("  Directed: ", length(which(grepl("-->", x[["edges"]], fixed=TRUE))), "\n")
        cat("  Bidirected: ", length(which(grepl("<->", x[["edges"]], fixed=TRUE))), "\n")
    }

    if (!is.null(x[["lambda"]])) {
        cat("lambda = {")
        for (i in 1:(length(x[["lambda"]])-1)) {
            cat(as.numeric(x[["lambda"]][i]), ", ", sep="")
        }
        cat(as.numeric(x[["lambda"]][length(x[["lambda"]])]), "}\n", sep="")
    }

    if (!is.null(x[["alpha"]])) {
        cat("alpha = ", as.numeric(x[["alpha"]]), "\n")
    }
    
    ## if (!is.null(x[["stabilities"]])) {
    ##     cat("Average instability: ", mean( 2 * x[["stabilities"]] * (1 - x[["stabilities"]]) ), "\n")
    ## }
    invisible(x)
}
