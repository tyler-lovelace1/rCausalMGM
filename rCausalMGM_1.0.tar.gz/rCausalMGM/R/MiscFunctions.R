#' A print override function for the graph class
#'
#' @param x The graph object
#' @export
print.graph <- function(x, ...) {
    cat("Algorithm: ", x[["algorithm"]], "\n")
    cat("Nodes: ", length(x[["nodes"]]), "\n")
    cat("Edges: ", length(x[["edges"]]), "\n")
    if (x[["type"]] != "undirected") {
        if (x[["type"]] == "partial ancestral graph") {
            cat("  Unoriented: ", sum(grepl("o-o", x[["edges"]], fixed=TRUE)), "\n")
            cat("  Partially Oriented: ", sum(grepl("o->", x[["edges"]], fixed=TRUE)), "\n")
            cat("  Directed: ", sum(grepl("-->", x[["edges"]], fixed=TRUE)), "\n")
            cat("  Bidirected: ", sum(grepl("<->", x[["edges"]], fixed=TRUE)), "\n")
        } else {
            cat("  Directed: ", sum(grepl("-->", x[["edges"]], fixed=TRUE)), "\n")
            cat("  Undirected: ", sum(grepl("---", x[["edges"]], fixed=TRUE)), "\n")
        }
        ## cat("  Directed: ", sum(grepl("-->", x[["edges"]], fixed=TRUE)), "\n")
        ## cat("  Bidirected: ", sum(grepl("<->", x[["edges"]], fixed=TRUE)), "\n")
    }

    if (!is.null(x[["lambda"]])) {
        cat("lambda = {")
        for (i in 1:(length(x[["lambda"]])-1)) {
            cat(as.numeric(x[["lambda"]][i]), ", ", sep="")
        }
        cat(as.numeric(x[["lambda"]][length(x[["lambda"]])]), "}\n", sep="")
    }

    if (!is.null(x[["alpha"]])) {
        cat("alpha = ", as.numeric(x[["alpha"]]), "\n")
    }
    
    ## if (!is.null(x[["stabilities"]])) {
    ##     cat("Average instability: ", mean( 2 * x[["stabilities"]] * (1 - x[["stabilities"]]) ), "\n")
    ## }
    invisible(x)
}

#' A print override function for the graphCV class
#'
#' @param x The graphCV object
#' @export
print.graphCV <- function(x, ...) {
    mgmFlag <- !is.null(x$lambdas)
    cat("Minimum cross-validation log(pseudo-likelihood) graph:\n")
    cat("  Index: ")
    cat(ifelse(mgmFlag,
               which(x$lambdas %in% x$lambda.min),
               which(x$alphas %in% x$alpha.min)))
    cat("\n\n")
    print(x$graph.min)
    cat("\n")
    cat("One standard error above the minimum cross-validation log(pseudo-likelihood) graph:\n")
    cat("  Index: ")
    cat(ifelse(mgmFlag,
               which(x$lambdas %in% x$lambda.1se),
               which(x$alphas %in% x$alpha.1se)))
    cat("\n\n")
    print(x$graph.1se)
    invisible(x)
}


#' A print override function for the graphPath class
#'
#' @param x The graphPath object
#' @export
print.graphPath <- function(x, ...) {
    mgmFlag <- !is.null(x$lambdas)
    cat("Minimum BIC graph:\n")
    cat("  Index: ")
    cat(which.min(x$BIC))
    cat("\n\n")
    print(x$graph.bic)
    cat("\n")
    cat("Minimum AIC graph:\n")
    cat("  Index: ")
    cat(which.min(x$AIC))
    cat("\n\n")
    print(x$graph.aic)
    invisible(x)
}


#' A print override function for the graphSTEPS class
#'
#' @param x The graphSTEPS object
#' @export
print.graphSTEPS <- function(x, gamma = NULL, ...) {
    mgmFlag <- !is.null(x$lambdas)
    if (is.null(gamma)) {
        gamma <- x$gamma
    }
    cat("StEPS selected graph:\n")
    print(x$graph)
    cat("\n")
    cat("StEPS selected lambda for gamma = ")
    cat(gamma)
    cat(":\n")
    allIdx <- c(1, which(x$instability[1:which.max(x$instability[,4]),4]<gamma))
    allIdx <- allIdx[length(allIdx)]
    ccIdx <- c(1, which(x$instability[1:which.max(x$instability[,1]),1]<gamma))
    ccIdx <- ccIdx[length(ccIdx)]
    cdIdx <- c(1, which(x$instability[1:which.max(x$instability[,2]),2]<gamma))
    cdIdx <- cdIdx[length(cdIdx)]
    ddIdx <- c(1, which(x$instability[1:which.max(x$instability[,3]),3]<gamma))
    ddIdx <- ddIdx[length(ddIdx)]
    cat(paste0("lambda = { ", x$lambdas[ccIdx], ", ", x$lambdas[cdIdx], ", ", x$lambdas[ddIdx], " }\n\n"))
    cat("StARS selected lambda for gamma = ")
    cat(gamma)
    cat(":\n")
    cat(paste0("lambda = ", x$lambdas[allIdx],"\n"))
    invisible(x)
}



#' A plot override function for the graph class
#'
#' @param x The graph object
#' @export
plot.graph <- function(x,
                       nodes = c(),
                       nodeAttr = list(),
                       edgeAttr = list(),
                       ...) {
    ## require("Rgraphviz")

    dotParams <- list(...)
    
    nodelist <- x[["nodes"]]
    
    if (length(nodes) > 0 & !all(is.element(nodes, nodelist))) {
        stop("elements in nodes must be in the graph")
    }

    if (length(nodes)==1) {
        nodes <- c(nodes, x[["markov.blankets"]][[nodes]])
    }
    
    edges <- strsplit(sort(x[["edges"]]), " ")

    edgeL <- list()

    for (i in 1:length(nodelist)) {
        edgeL[[nodelist[i]]] <- list(edges = c(), weights = c())
    }

    edgeorient <- list(arrowhead = c(),
                       arrowtail = c())

    for (i in 1:length(edges)) {
        edgeL[[edges[[i]][1]]] <-
            list(edges = c(edgeL[[edges[[i]][1]]][["edges"]], edges[[i]][3]),
                 weights = c(edgeL[[edges[[i]][1]]][["weights"]], 1))

        edgename <- paste(edges[[i]][c(1, 3)], collapse = "~")
        edgetype <- edges[[i]][2]
        
        edgeorient[["arrowhead"]] <-
            c(edgeorient[["arrowhead"]],
              ifelse(any(edgetype == c("-->", "o->", "<->")), "open",
              ifelse(edgetype == "o-o", "odot", "none")))
        
        names(edgeorient[["arrowhead"]])[i] <- edgename

        edgeorient[["arrowtail"]] <-
            c(edgeorient[["arrowtail"]],
              ifelse(any(edgetype == c("o-o", "o->")), "odot",
              ifelse(edgetype == "<->", "open", "none")))
        
        names(edgeorient[["arrowtail"]])[i] <- edgename
    }

    rgraph <- graph::graphNEL(nodelist, edgeL, "directed")

    if (length(nodes) > 0) {
        rgraph <- graph::subGraph(nodes, rgraph)
        
        edgeorient[["arrowhead"]] <-
            edgeorient[["arrowhead"]][graph::edgeNames(rgraph)]
        
        edgeorient[["arrowtail"]] <-
            edgeorient[["arrowtail"]][graph::edgeNames(rgraph)]
    }

    if (length(nodeAttr) > 0) {
        graph::nodeRenderInfo(rgraph) <- nodeAttr
    }
    
    edgeAttr[["arrowhead"]] <- edgeorient[["arrowhead"]]
    edgeAttr[["arrowtail"]] <- edgeorient[["arrowtail"]]
    
    graph::edgeRenderInfo(rgraph) <- edgeAttr

    if (is.null(dotParams[["main"]])) {
        dotParams[["main"]] <-
            paste0(x[["algorithm"]], 
                   ifelse(is.null(x[["lambda"]]), c(""),
                          paste0("\nlambda = {",
                                 paste(as.numeric(round(x[["lambda"]], 3)),
                                       collapse=", "), "}")),
                   ifelse(is.null(x[["alpha"]]), c(""),
                          paste0("\nalpha = ",
                                 as.numeric(x[["alpha"]]))))
    }

    graph::graph.par(list(graph = append(list(main = dotParams[["main"]]),
                                         dotParams[-which(names(dotParams) == "main")])))

    rgraph <- Rgraphviz::layoutGraph(rgraph)

    Rgraphviz::renderGraph(rgraph)
    
    ## Rgraphviz::plot(rgraph)
}

#' A plot override function for the graphCV class
#'
#' @param x The graph object
#' @export
plot.graphCV <- function(x, ...) {
    mgmFlag <- !is.null(x$lambdas)
    
    if (mgmFlag) {
        log10params <- log10(x$lambdas)
    } else {
        log10params <- log10(x$alphas)
    }
    
    llMeans <- rowMeans(x$loglik)
    llSe <- apply(x$loglik, 1, sd)

    ll.range <- (max(llMeans + llSe) - min(llMeans - llSe))
    ll.lims <- c(min(llMeans - llSe) - 0.025 * ll.range,
                 max(llMeans + llSe) + 0.025 * ll.range)

    plot(x=log10params, y=llMeans, col='red', pch=19,
         xlab=ifelse(mgmFlag, expression(log10(lambda)), expression(log10(alpha))),
         ylab="-log(Pseudo-Likelihood)", ylim=ll.lims)
    
    arrows(x0=log10params, x1=log10params, y0=llMeans-llSe, code=3, angle=90,
           length=0.05, y1=llMeans+llSe, col='darkgray')
    
    abline(v=ifelse(mgmFlag, log10(x$lambda.min[1]), log10(x$alpha.min[1])),
           col='black', lty=3, lw=2)
    
    abline(v=ifelse(mgmFlag, log10(x$lambda.1se[1]), log10(x$alpha.1se[1])),
           col='black', lty=3, lw=2)
}

#' A plot override function for the graphCV class
#'
#' @param x The graph object
#' @export
plot.graphPath <- function(x, ...) {
    mgmFlag <- !is.null(x$lambdas)

    if (mgmFlag) {
        log10params <- log10(x$lambdas)
    } else {
        log10params <- log10(x$alphas)
    }
    
    score.range <- (max(x$BIC) - min(x$AIC)) / (2 * x$n)
    score.lims <- c(min(x$AIC) / (2 * x$n) - 0.025 * score.range,
                    max(x$BIC) / (2 * x$n) + 0.025 * score.range)

    plot(x=log10params, y=x$BIC / (2 * x$n), col='red', pch=19,
         xlab=ifelse(mgmFlag, expression(log10(lambda)), expression(log10(alpha))),
         ylab="Sample Averaged Score", ylim=score.lims)

    points(x=log10params, y=x$AIC / (2 * x$n), col='blue', pch=19)

    legend(x = "bottomright", title="Scores", 
           legend=c("AIC", "BIC"), 
           col = c("blue","red"),
           pch=19, cex=0.7)

    abline(v=ifelse(mgmFlag,
                    log10(x$lambdas[which.min(x$AIC)]),
                    log10(x$alphas[which.min(x$AIC)])),
           col='blue', lty=3, lw=2)
    
    abline(v=ifelse(mgmFlag,
                    log10(x$lambdas[which.min(x$BIC)]),
                    log10(x$alphas[which.min(x$BIC)])),
           col='red', lty=3, lw=2)
}

#' A plot override function for the graphSTEPS class
#'
#' @param x The graph object
#' @export
plot.graphSTEPS <- function(x, gamma=NULL, ...) {
    mgmFlag <- !is.null(x$lambdas)

    if (is.null(gamma)) {
        gamma <- x$gamma
    }

    if (mgmFlag) {
        log10params <- log10(x$lambdas)
    } else {
        log10params <- log10(x$alphas)
    }

    plot(x=log10params, y=x$instability[,4], col='black', pch=19,
         xlab=ifelse(mgmFlag, expression(log10(lambda)), expression(log10(alpha))),
         ylab="Edge instability across subsamples", ylim=c(0,0.5))

    points(x=log10params, y=x$instability[,1], col='red', pch=18)
    points(x=log10params, y=x$instability[,2], col='blue', pch=17)
    points(x=log10params, y=x$instability[,3], col='purple', pch=15)

    abline(h=gamma, lty=2, col='gray', lw=2)

    allIdx <- c(1, which(x$instability[1:which.max(x$instability[,4]),4]<gamma))
    allIdx <- allIdx[length(allIdx)]
    ccIdx <- c(1, which(x$instability[1:which.max(x$instability[,1]),1]<gamma))
    ccIdx <- ccIdx[length(ccIdx)]
    cdIdx <- c(1, which(x$instability[1:which.max(x$instability[,2]),2]<gamma))
    cdIdx <- cdIdx[length(cdIdx)]
    ddIdx <- c(1, which(x$instability[1:which.max(x$instability[,3]),3]<gamma))
    ddIdx <- ddIdx[length(ddIdx)]
    
    abline(v=log10params[allIdx], col='black',  lty=3, lw=2)
    abline(v=log10params[ccIdx],  col='red',    lty=3, lw=2)
    abline(v=log10params[cdIdx],  col='blue',   lty=3, lw=2)
    abline(v=log10params[ddIdx],  col='purple', lty=3, lw=2)

    legend(x = "topleft", title="Edge Type", 
           legend = c("All", "C-C", "C-D", "D-D"), 
           col = c("black","red", "blue", "purple"),
           pch = c(19, 18, 17, 15), cex=0.7)
}

#' A table to generate a data.frame for objects from graph class. It incorporates
#' adjacency and orientation frequency if estimates of edge stability are available.
#'
#' @param graph The graph object
#' @param stabilities The stability data.frame from bootstrapping or StEPS. If NULL,
#' the stabilities entry of the graph object is used. If that is also NULL, only edge
#' interactions are returned. The default is NULL
#' @export
graphTable <- function(graph, stabilities = NULL) {

    if (is.null(stabilities)) {
        stabilities <- graph[["stabilities"]]
    }

    if (is.null(stabilities)) {
        graph.table <- data.frame(source=c(),
                                  target=c(),
                                  interaction=c())

        idx <- 1
        for (edge in graph$edges) {
            edge <- strsplit(edge, " ")[[1]]

            if (edge[2] == "---") {
                inter <- "undir"
            } else if (edge[2] == "-->") {
                inter <- "dir"
            } else if (edge[2] == "o->") {
                inter <- "ca"
            } else if (edge[2] == "<->") {
                inter <- "bidir"
            } else if (edge[2] == "o-o") {
                inter <- "cc"
            }

            tempRow <- data.frame(source=c(edge[1]),
                                  target=c(edge[3]),
                                  interaction=c(inter))
                    
            graph.table <- rbind(graph.table, tempRow)
        }
            
    } else if (graph[["type"]] == "undirected") {
        
        graph.table <- data.frame(source=c(),
                                  target=c(),
                                  interaction=c(),            
                                  adjacency.freq=c())
        
        if ((ncol(stabilities) == nrow(stabilities)) &&
            all(colnames(stabilities) == rownames(stabilities))) {

            idx <- 1
            for (edge in graph$edges) {
                edge <- strsplit(edge, " ")[[1]]
                
                tempRow <- data.frame(
                    source=c(edge[1]),
                    target=c(edge[3]),
                    interaction=c("undir"),
                    adjacency.freq=c(stabilities[edge[1], edge[3]]))
                    
                graph.table <- rbind(graph.table, tempRow)
            }
        } else {
            
            idx <- 1
            for (edge in graph$edges) {
                edge <- strsplit(edge, " ")[[1]]

                for (i in 1:nrow(stabilities)) {
                    if ((edge[1] == stabilities[i,1] &&
                         edge[3] == stabilities[i,3]) ||
                        (edge[1] == stabilities[i,3] &&
                         edge[3] == stabilities[i,1])) {

                        adj.freq <- 1-stabilities[i,"none"]
                        tempRow <- data.frame(
                            source=c(edge[1]),
                            target=c(edge[3]),
                            interaction=c("undir"),
                            adjacency.freq=c(adj.freq))
                
                        graph.table <- rbind(graph.table, tempRow)
                        
                        break
                    }
                }
            }
        }
        
    } else {
        graph.table <- data.frame(source=c(),
                                  target=c(),
                                  interaction=c(),            
                                  adjacency.freq=c(),
                                  orientation.freq=c())
        idx <- 1
        for (edge in graph$edges) {
            edge <- strsplit(edge, " ")[[1]]
            
            for (i in 1:nrow(stabilities)) {
                if (edge[1] == stabilities[i,1] &&
                    edge[3] == stabilities[i,3]) {
                    
                    adj.freq <- 1-stabilities[i,"none"]
                    if (edge[2] == "---") {
                        orient.freq <- stabilities[i,"undir"]
                        inter <- "undir"
                    } else if (edge[2] == "-->") {
                        orient.freq <- stabilities[i,"right.dir"]
                        inter <- "dir"
                    } else if (edge[2] == "o->") {
                        orient.freq <- stabilities[i,"right.partdir"]
                        inter <- "ca"
                    } else if (edge[2] == "<->") {
                        orient.freq <- stabilities[i,"bidir"]
                        inter <- "bidir"
                    } else if (edge[2] == "o-o") {
                        orient.freq <- stabilities[i,"nondir"]
                        inter <- "cc"
                    }
                    
                    tempRow <- data.frame(source=c(edge[1]),
                                          target=c(edge[3]),
                                          interaction=c(inter),
                                          adjacency.freq=c(adj.freq),
                                          orientation.freq=c(orient.freq))
                    
                    graph.table <- rbind(graph.table, tempRow)

                    break
                    
                } else if (edge[1] == stabilities[i,3] &&
                           edge[3] == stabilities[i,1]) {
                    
                    adj.freq <- 1-stabilities[i,"none"]
                    if (edge[2] == "---") {
                        orient.freq <- stabilities[i,"undir"]
                        inter <- "undir"
                    } else if (edge[2] == "-->") {
                        orient.freq <- stabilities[i,"left.dir"]
                        inter <- "dir"
                    } else if (edge[2] == "o->") {
                        orient.freq <- stabilities[i,"left.partdir"]
                        inter <- "ca"
                    } else if (edge[2] == "<->") {
                        orient.freq <- stabilities[i,"bidir"]
                        inter <- "bidir"
                    } else if (edge[2] == "o-o") {
                        orient.freq <- stabilities[i,"nondir"]
                        inter <- "cc"
                    }
                    
                    tempRow <- data.frame(source=c(edge[1]),
                                          target=c(edge[3]),
                                          interaction=c(inter),
                                          adjacency.freq=c(adj.freq),
                                          orientation.freq=c(orient.freq))
                    
                    graph.table <- rbind(graph.table, tempRow)

                    break
                }
            }
        }
    }
    
    return(graph.table)
    
}

#' A as.data.frame override function for the graph class
#'
#' @param x The graph object
#' @export
as.data.frame.graph <- function(x, ...) {
    return(graphTable(x))
}
